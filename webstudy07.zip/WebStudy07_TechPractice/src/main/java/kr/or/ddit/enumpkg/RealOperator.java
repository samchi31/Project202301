package kr.or.ddit.enumpkg;

@FunctionalInterface
public interface RealOperator {
	public int operate(int leftOp, int rightOp);
}
