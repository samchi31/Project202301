package kr.or.ddit.ui;

public interface PaginationManager {
	public PaginationRenderer rendererType(String type);
}
